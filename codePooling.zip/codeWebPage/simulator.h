
void init();
void printQueue();
int isInList(int arg, int* list, int listSize);
int drawTypeOfClient();
void movePackets(int listIndex[], int size);
void updateQueue();
int updateSimulator(int algo);
void simulate(int algo);

