void testUnitaireRealisticMaxPool();

